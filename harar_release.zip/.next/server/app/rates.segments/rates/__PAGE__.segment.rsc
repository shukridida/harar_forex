1:"$Sreact.fragment"
2:I[50906,["/_next/static/chunks/01xlw8hd842-c.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/0t1ow3pl_bavn.js"],"default"]
3:I[97367,["/_next/static/chunks/01xlw8hd842-c.js","/_next/static/chunks/0d3shmwh5_nmn.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","main",null,{"className":"min-h-screen bg-[#14B8A6] text-white p-6","children":[["$","h1",null,{"className":"text-3xl font-bold text-[#166534] mb-6","children":"Live Exchange Rates"}],["$","div",null,{"className":"bg-white/10 p-6 rounded-lg shadow-md","children":["$","$L2",null,{}]}]]}],[["$","script","script-0",{"src":"/_next/static/chunks/0t1ow3pl_bavn.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"Xfvfuu-_Yqg9fdxPrKxdm"}
5:null
