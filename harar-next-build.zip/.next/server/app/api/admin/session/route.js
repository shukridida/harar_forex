var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/session/route.js")
R.c("server/chunks/[root-of-the-server]__039o6vx._.js")
R.c("server/chunks/node_modules_next_dist_0npcise._.js")
R.c("server/chunks/[root-of-the-server]__0trr_rb._.js")
R.c("server/chunks/[root-of-the-server]__0op9af~._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_session_route_actions_0sr_2sa.js")
R.m(59862)
module.exports=R.m(59862).exports
