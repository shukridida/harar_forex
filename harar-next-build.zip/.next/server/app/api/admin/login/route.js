var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/login/route.js")
R.c("server/chunks/[root-of-the-server]__0l4secw._.js")
R.c("server/chunks/node_modules_next_dist_0npcise._.js")
R.c("server/chunks/[root-of-the-server]__0op9af~._.js")
R.c("server/chunks/[root-of-the-server]__00zq~9o._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_login_route_actions_0o428.q.js")
R.m(10620)
module.exports=R.m(10620).exports
