var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/contact/route.js")
R.c("server/chunks/[externals]__0tb5yld._.js")
R.c("server/chunks/[root-of-the-server]__0cgutg9._.js")
R.c("server/chunks/[root-of-the-server]__0op9af~._.js")
R.c("server/chunks/_next-internal_server_app_api_contact_route_actions_02158u4.js")
R.m(74493)
module.exports=R.m(74493).exports
