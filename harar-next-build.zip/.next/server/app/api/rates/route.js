var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/rates/route.js")
R.c("server/chunks/[root-of-the-server]__0~lq4ib._.js")
R.c("server/chunks/node_modules_next_dist_0npcise._.js")
R.c("server/chunks/[root-of-the-server]__0op9af~._.js")
R.c("server/chunks/[root-of-the-server]__08me-hk._.js")
R.c("server/chunks/_next-internal_server_app_api_rates_route_actions_0zmnr4t.js")
R.m(96618)
module.exports=R.m(96618).exports
