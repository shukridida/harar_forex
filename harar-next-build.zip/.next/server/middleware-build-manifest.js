globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/IYfzWi8ULvLfE-2r9b2U8/_buildManifest.js",
    "static/IYfzWi8ULvLfE-2r9b2U8/_ssgManifest.js",
    "static/IYfzWi8ULvLfE-2r9b2U8/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0ht900cau6_ur.js",
    "static/chunks/0dgq26a5_oy.a.js",
    "static/chunks/0mstyq17cbf8-.js",
    "static/chunks/164gi2othr039.js",
    "static/chunks/turbopack-0hspyj_h0zai6.js"
  ]
};
